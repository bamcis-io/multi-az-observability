'''
# multi-az-observability
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

from typeguard import check_type

from ._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_ec2 as _aws_cdk_aws_ec2_ceddda9d
import aws_cdk.aws_elasticloadbalancingv2 as _aws_cdk_aws_elasticloadbalancingv2_ceddda9d
import constructs as _constructs_77d1e7e8


@jsii.interface(
    jsii_type="multi-az-observability.IBasicServiceMultiAZObservabilityProps"
)
class IBasicServiceMultiAZObservabilityProps(typing_extensions.Protocol):
    '''Properties for creating a basic service.'''

    @builtins.property
    @jsii.member(jsii_name="applicationLoadBalancers")
    def application_load_balancers(
        self,
    ) -> typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer]:
        '''The application load balancers being used by the service.'''
        ...

    @application_load_balancers.setter
    def application_load_balancers(
        self,
        value: typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer],
    ) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="faultCountPercentageThreshold")
    def fault_count_percentage_threshold(self) -> jsii.Number:
        '''The percentage of faults for a single ALB to consider an AZ to be unhealthy, this should align with your availability goal.'''
        ...

    @fault_count_percentage_threshold.setter
    def fault_count_percentage_threshold(self, value: jsii.Number) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="natGateways")
    def nat_gateways(
        self,
    ) -> typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]]:
        '''(Optional) A map of Availability Zone name to the NAT Gateways in that AZ.'''
        ...

    @nat_gateways.setter
    def nat_gateways(
        self,
        value: typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]],
    ) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="outlierDetectionAlgorithm")
    def outlier_detection_algorithm(self) -> "OutlierDetectionAlgorithm":
        '''The algorithm to use for performing outlier detection.'''
        ...

    @outlier_detection_algorithm.setter
    def outlier_detection_algorithm(self, value: "OutlierDetectionAlgorithm") -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="outlierThreshold")
    def outlier_threshold(self) -> jsii.Number:
        '''The threshold for percentage of errors or packet loss to determine if an AZ is an outlier, should be a number between  0 and 1.'''
        ...

    @outlier_threshold.setter
    def outlier_threshold(self, value: jsii.Number) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="packetLossImpactPercentageThreshold")
    def packet_loss_impact_percentage_threshold(self) -> jsii.Number:
        '''The amount of packet loss in a NAT GW to determine if an AZ is actually impacted, recommendation is 0.01%.'''
        ...

    @packet_loss_impact_percentage_threshold.setter
    def packet_loss_impact_percentage_threshold(self, value: jsii.Number) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="period")
    def period(self) -> _aws_cdk_ceddda9d.Duration:
        '''The period to evaluate metrics.'''
        ...

    @period.setter
    def period(self, value: _aws_cdk_ceddda9d.Duration) -> None:
        ...

    @builtins.property
    @jsii.member(jsii_name="serviceName")
    def service_name(self) -> builtins.str:
        '''The service's name.'''
        ...

    @service_name.setter
    def service_name(self, value: builtins.str) -> None:
        ...


class _IBasicServiceMultiAZObservabilityPropsProxy:
    '''Properties for creating a basic service.'''

    __jsii_type__: typing.ClassVar[str] = "multi-az-observability.IBasicServiceMultiAZObservabilityProps"

    @builtins.property
    @jsii.member(jsii_name="applicationLoadBalancers")
    def application_load_balancers(
        self,
    ) -> typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer]:
        '''The application load balancers being used by the service.'''
        return typing.cast(typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer], jsii.get(self, "applicationLoadBalancers"))

    @application_load_balancers.setter
    def application_load_balancers(
        self,
        value: typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a212eb4312725e6d19765ba309627fd08c9938c60f7bf2a0ad226da134d063a1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "applicationLoadBalancers", value)

    @builtins.property
    @jsii.member(jsii_name="faultCountPercentageThreshold")
    def fault_count_percentage_threshold(self) -> jsii.Number:
        '''The percentage of faults for a single ALB to consider an AZ to be unhealthy, this should align with your availability goal.'''
        return typing.cast(jsii.Number, jsii.get(self, "faultCountPercentageThreshold"))

    @fault_count_percentage_threshold.setter
    def fault_count_percentage_threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8e008035ca3a968106cfb46d35342936dce0afbf4c3acc7fbf91d677fcf6105)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "faultCountPercentageThreshold", value)

    @builtins.property
    @jsii.member(jsii_name="natGateways")
    def nat_gateways(
        self,
    ) -> typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]]:
        '''(Optional) A map of Availability Zone name to the NAT Gateways in that AZ.'''
        return typing.cast(typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]], jsii.get(self, "natGateways"))

    @nat_gateways.setter
    def nat_gateways(
        self,
        value: typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05ac138ce3d376e542d48977a426e7dc2f124336d73b46a1e77fdd106e07893d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "natGateways", value)

    @builtins.property
    @jsii.member(jsii_name="outlierDetectionAlgorithm")
    def outlier_detection_algorithm(self) -> "OutlierDetectionAlgorithm":
        '''The algorithm to use for performing outlier detection.'''
        return typing.cast("OutlierDetectionAlgorithm", jsii.get(self, "outlierDetectionAlgorithm"))

    @outlier_detection_algorithm.setter
    def outlier_detection_algorithm(self, value: "OutlierDetectionAlgorithm") -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93d5c462f58bcf486f480669a06e0a58cd71d24d76e513a5f15f58c46fffa84c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "outlierDetectionAlgorithm", value)

    @builtins.property
    @jsii.member(jsii_name="outlierThreshold")
    def outlier_threshold(self) -> jsii.Number:
        '''The threshold for percentage of errors or packet loss to determine if an AZ is an outlier, should be a number between  0 and 1.'''
        return typing.cast(jsii.Number, jsii.get(self, "outlierThreshold"))

    @outlier_threshold.setter
    def outlier_threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3436292fb9632dcd0599d6c964039ad1d89e9b790e03d0ffd93fbd17e5a5e90)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "outlierThreshold", value)

    @builtins.property
    @jsii.member(jsii_name="packetLossImpactPercentageThreshold")
    def packet_loss_impact_percentage_threshold(self) -> jsii.Number:
        '''The amount of packet loss in a NAT GW to determine if an AZ is actually impacted, recommendation is 0.01%.'''
        return typing.cast(jsii.Number, jsii.get(self, "packetLossImpactPercentageThreshold"))

    @packet_loss_impact_percentage_threshold.setter
    def packet_loss_impact_percentage_threshold(self, value: jsii.Number) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdb136a9c6225aa905e3e2f83f98d220ea52df8762796a29f7a658d94a15d33e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "packetLossImpactPercentageThreshold", value)

    @builtins.property
    @jsii.member(jsii_name="period")
    def period(self) -> _aws_cdk_ceddda9d.Duration:
        '''The period to evaluate metrics.'''
        return typing.cast(_aws_cdk_ceddda9d.Duration, jsii.get(self, "period"))

    @period.setter
    def period(self, value: _aws_cdk_ceddda9d.Duration) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee75823442db3b24d1527bad6ef2b67aae361b06f4ac0649c204e85a752b5560)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "period", value)

    @builtins.property
    @jsii.member(jsii_name="serviceName")
    def service_name(self) -> builtins.str:
        '''The service's name.'''
        return typing.cast(builtins.str, jsii.get(self, "serviceName"))

    @service_name.setter
    def service_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ccd4db0848d6622f0e46d7cbe0b48cd226a9a480739bcee2621a0b91f250c876)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "serviceName", value)

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IBasicServiceMultiAZObservabilityProps).__jsii_proxy_class__ = lambda : _IBasicServiceMultiAZObservabilityPropsProxy


@jsii.interface(jsii_type="multi-az-observability.IMultiAvailabilityZoneObservability")
class IMultiAvailabilityZoneObservability(typing_extensions.Protocol):
    pass


class _IMultiAvailabilityZoneObservabilityProxy:
    __jsii_type__: typing.ClassVar[str] = "multi-az-observability.IMultiAvailabilityZoneObservability"
    pass

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IMultiAvailabilityZoneObservability).__jsii_proxy_class__ = lambda : _IMultiAvailabilityZoneObservabilityProxy


@jsii.interface(
    jsii_type="multi-az-observability.IMultiAvailabilityZoneObservabilityProps"
)
class IMultiAvailabilityZoneObservabilityProps(typing_extensions.Protocol):
    @builtins.property
    @jsii.member(jsii_name="basicServiceObservabilityProps")
    def basic_service_observability_props(
        self,
    ) -> IBasicServiceMultiAZObservabilityProps:
        ...

    @basic_service_observability_props.setter
    def basic_service_observability_props(
        self,
        value: IBasicServiceMultiAZObservabilityProps,
    ) -> None:
        ...


class _IMultiAvailabilityZoneObservabilityPropsProxy:
    __jsii_type__: typing.ClassVar[str] = "multi-az-observability.IMultiAvailabilityZoneObservabilityProps"

    @builtins.property
    @jsii.member(jsii_name="basicServiceObservabilityProps")
    def basic_service_observability_props(
        self,
    ) -> IBasicServiceMultiAZObservabilityProps:
        return typing.cast(IBasicServiceMultiAZObservabilityProps, jsii.get(self, "basicServiceObservabilityProps"))

    @basic_service_observability_props.setter
    def basic_service_observability_props(
        self,
        value: IBasicServiceMultiAZObservabilityProps,
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f05da0c0bdbed0525bd1f9202398c5ffc23e5f3653c627ed3b258f4735503d6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "basicServiceObservabilityProps", value)

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IMultiAvailabilityZoneObservabilityProps).__jsii_proxy_class__ = lambda : _IMultiAvailabilityZoneObservabilityPropsProxy


@jsii.implements(IMultiAvailabilityZoneObservability)
class MultiAvailabilityZoneObservability(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="multi-az-observability.MultiAvailabilityZoneObservability",
):
    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        props: IMultiAvailabilityZoneObservabilityProps,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param props: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db7722a261680b08dcb22ac8252318147a49062ef75183b4ed6c0c1bb748c471)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument props", value=props, expected_type=type_hints["props"])
        jsii.create(self.__class__, self, [scope, id, props])


@jsii.enum(jsii_type="multi-az-observability.OutlierDetectionAlgorithm")
class OutlierDetectionAlgorithm(enum.Enum):
    '''Available algorithms for performing outlier detection, currently only STATIC is supported.'''

    STATIC = "STATIC"
    '''Defines using a static value to compare skew in faults or high latency responses.'''
    CHI_SQUARED = "CHI_SQUARED"
    '''Uses the chi squared statistic to determine if there is a statistically significant skew in fault rate or high latency distribution.'''
    Z_SCORE = "Z_SCORE"
    '''Uses z-score to determine if the skew in faults or high latency respones exceeds a defined number of standard devations (typically 3).'''


__all__ = [
    "IBasicServiceMultiAZObservabilityProps",
    "IMultiAvailabilityZoneObservability",
    "IMultiAvailabilityZoneObservabilityProps",
    "MultiAvailabilityZoneObservability",
    "OutlierDetectionAlgorithm",
]

publication.publish()

def _typecheckingstub__a212eb4312725e6d19765ba309627fd08c9938c60f7bf2a0ad226da134d063a1(
    value: typing.List[_aws_cdk_aws_elasticloadbalancingv2_ceddda9d.IApplicationLoadBalancer],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8e008035ca3a968106cfb46d35342936dce0afbf4c3acc7fbf91d677fcf6105(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05ac138ce3d376e542d48977a426e7dc2f124336d73b46a1e77fdd106e07893d(
    value: typing.Mapping[builtins.str, typing.List[_aws_cdk_aws_ec2_ceddda9d.CfnNatGateway]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93d5c462f58bcf486f480669a06e0a58cd71d24d76e513a5f15f58c46fffa84c(
    value: OutlierDetectionAlgorithm,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3436292fb9632dcd0599d6c964039ad1d89e9b790e03d0ffd93fbd17e5a5e90(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdb136a9c6225aa905e3e2f83f98d220ea52df8762796a29f7a658d94a15d33e(
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee75823442db3b24d1527bad6ef2b67aae361b06f4ac0649c204e85a752b5560(
    value: _aws_cdk_ceddda9d.Duration,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ccd4db0848d6622f0e46d7cbe0b48cd226a9a480739bcee2621a0b91f250c876(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f05da0c0bdbed0525bd1f9202398c5ffc23e5f3653c627ed3b258f4735503d6(
    value: IBasicServiceMultiAZObservabilityProps,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db7722a261680b08dcb22ac8252318147a49062ef75183b4ed6c0c1bb748c471(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    props: IMultiAvailabilityZoneObservabilityProps,
) -> None:
    """Type checking stubs"""
    pass
